export declare class AppModule {}
