export interface IntegrationModuleOptions {
  url: string;
  secure?: boolean;
}
