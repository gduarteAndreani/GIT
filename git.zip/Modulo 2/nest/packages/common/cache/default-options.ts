export const defaultCacheOptions = {
  ttl: 5,
  max: 100,
  store: 'memory',
};
